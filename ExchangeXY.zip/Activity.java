public class test {
    public static void main(String[] args) {
        int x=14, y=7, z;

        z = x;
        x = x * 0 + y;
        y = y * 0 + z;

        System.out.println("X= " + x);
        System.out.println("Y= " + y);
    }
}
