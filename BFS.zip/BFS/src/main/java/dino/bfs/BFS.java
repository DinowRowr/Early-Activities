package dino.bfs;
import java.util.*;

public class BFS {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] knights = new int[4];
        for (int i = 0; i < 4; i++) {
            knights[i] = scanner.nextInt();
        }
        int flag = scanner.nextInt();

        int[] moves = getMinimumMoves(knights, flag);
        char firstKnight = getFirstKnight(moves);

        System.out.println(firstKnight);
    }

    public static int[] getMinimumMoves(int[] knights, int flag) {
        int[][] distances = new int[64][64];

        for (int i = 0; i < 64; i++) {
            Arrays.fill(distances[i], -1);
            distances[i][i] = 0;
        }

        for (int i = 0; i < 64; i++) {
            int row = i / 8;
            int col = i % 8;

            int[] offsets = { -2, -1, 1, 2 };

            for (int dx : offsets) {
                for (int dy : offsets) {
                    if (Math.abs(dx) != Math.abs(dy)) {
                        int newRow = row + dx;
                        int newCol = col + dy;

                        if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                            int j = newRow * 8 + newCol;
                            distances[i][j] = 1;
                        }
                    }
                }
            }
        }

        for (int k = 0; k < 64; k++) {
            for (int i = 0; i < 64; i++) {
                for (int j = 0; j < 64; j++) {
                    if (distances[i][k] != -1 && distances[k][j] != -1) {
                        if (distances[i][j] == -1 || distances[i][j] > distances[i][k] + distances[k][j]) {
                            distances[i][j] = distances[i][k] + distances[k][j];
                        }
                    }
                }
            }
        }

        int[] moves = new int[4];
        for (int i = 0; i < 4; i++) {
            moves[i] = distances[knights[i]][flag];
        }

        return moves;
    }

    public static char getFirstKnight(int[] moves) {
        char[] knights = { 'B', 'G', 'O', 'Y' };
        int minMoves = Integer.MAX_VALUE;
        char firstKnight = ' ';

        for (int i = 0; i < 4; i++) {
            if (moves[i] != -1 && moves[i] < minMoves) {
                minMoves = moves[i];
                firstKnight = knights[i];
            }
        }

        return firstKnight;
    }
}















