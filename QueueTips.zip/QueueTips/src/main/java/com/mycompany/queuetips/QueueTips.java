package com.mycompany.queuetips;

/**
 *
 * @author Dinothelo P. Quiroga
 */
import java.util.*;

public class QueueTips {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read the number of people in the queue
        int n = scanner.nextInt();

        // Read the heights of the people in the queue
        int[] heights = new int[n];
        for (int i = 0; i < n; i++) {
            heights[i] = scanner.nextInt();
        }

        // Calculate the number of visible people for each person
        int[] visiblePeople = new int[n];
        Stack<Integer> stack = new Stack<>();

        for (int i = 0; i < n; i++) {
            while (!stack.isEmpty() && heights[i] >= heights[stack.peek()]) {
                stack.pop();
            }

            if (!stack.isEmpty()) {
                visiblePeople[i] = i - stack.peek();
            } else {
                visiblePeople[i] = i;
            }

            stack.push(i);
        }

        // Adjust visible people if the person in front has the same height
        for (int i = 1; i < n; i++) {
            if (heights[i - 1] == heights[i]) {
                visiblePeople[i] = 1;
            }
        }

        // Print the number of visible people for each person
        for (int i = 0; i < n; i++) {
            System.out.print(visiblePeople[i] + " ");
        }
    }
}





