import java.util.Scanner;

public class SecurityPin {
    
    public static void main(String[]args) {
        try (Scanner pin = new Scanner(System.in)) {
            
            int num = 12345;
            
            System.out.println("Enter your PIN:");
            int entry = pin.nextInt();
            
            while (entry != num)
            {
                System.out.println("\nIncorrect PIN! Try again!");
                System.out.println("Enter your PIN:");
                entry = pin.nextInt();
            }
        }
        System.out.println("\nPIN accepted!");
    }
}